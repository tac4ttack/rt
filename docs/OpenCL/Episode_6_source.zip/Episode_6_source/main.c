/*
 Copyright 2009 David W. Gohara, Ph.D. and MacResearch.org
 http://www.macresearch.org/opencl
 */
#include <libc.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <mach/mach_time.h>
#include <math.h>

#include <OpenCL/opencl.h>

#define SEP printf("-----------------------------------------------------------\n")

int device_stats(cl_device_id device_id){
	
	int err;
	size_t returned_size;
	
	// Report the device vendor and device name
    // 
    cl_char vendor_name[1024] = {0};
    cl_char device_name[1024] = {0};
	cl_char device_profile[1024] = {0};
	cl_char device_extensions[1024] = {0};
	cl_device_local_mem_type local_mem_type;
	
    cl_ulong global_mem_size, global_mem_cache_size;
	cl_ulong max_mem_alloc_size;
	
	cl_uint clock_frequency, vector_width, max_compute_units;
	
	size_t max_work_item_dims,max_work_group_size, max_work_item_sizes[3];
	
	cl_uint vector_types[] = {CL_DEVICE_PREFERRED_VECTOR_WIDTH_CHAR, CL_DEVICE_PREFERRED_VECTOR_WIDTH_SHORT, CL_DEVICE_PREFERRED_VECTOR_WIDTH_INT,CL_DEVICE_PREFERRED_VECTOR_WIDTH_LONG,CL_DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT,CL_DEVICE_PREFERRED_VECTOR_WIDTH_DOUBLE}; 
	char *vector_type_names[] = {"char","short","int","long","float","double"};
	
	err = clGetDeviceInfo(device_id, CL_DEVICE_VENDOR, sizeof(vendor_name), vendor_name, &returned_size);
    err|= clGetDeviceInfo(device_id, CL_DEVICE_NAME, sizeof(device_name), device_name, &returned_size);
	err|= clGetDeviceInfo(device_id, CL_DEVICE_PROFILE, sizeof(device_profile), device_profile, &returned_size);
	err|= clGetDeviceInfo(device_id, CL_DEVICE_EXTENSIONS, sizeof(device_extensions), device_extensions, &returned_size);
	err|= clGetDeviceInfo(device_id, CL_DEVICE_LOCAL_MEM_TYPE, sizeof(local_mem_type), &local_mem_type, &returned_size);
	
	err|= clGetDeviceInfo(device_id, CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(global_mem_size), &global_mem_size, &returned_size);
	err|= clGetDeviceInfo(device_id, CL_DEVICE_GLOBAL_MEM_CACHELINE_SIZE, sizeof(global_mem_cache_size), &global_mem_cache_size, &returned_size);
	err|= clGetDeviceInfo(device_id, CL_DEVICE_MAX_MEM_ALLOC_SIZE, sizeof(max_mem_alloc_size), &max_mem_alloc_size, &returned_size);
	
	err|= clGetDeviceInfo(device_id, CL_DEVICE_MAX_CLOCK_FREQUENCY, sizeof(clock_frequency), &clock_frequency, &returned_size);
	
	err|= clGetDeviceInfo(device_id, CL_DEVICE_MAX_WORK_GROUP_SIZE, sizeof(max_work_group_size), &max_work_group_size, &returned_size);
	
	err|= clGetDeviceInfo(device_id, CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS, sizeof(max_work_item_dims), &max_work_item_dims, &returned_size);
	
	err|= clGetDeviceInfo(device_id, CL_DEVICE_MAX_WORK_ITEM_SIZES, sizeof(max_work_item_sizes), max_work_item_sizes, &returned_size);
	
	err|= clGetDeviceInfo(device_id, CL_DEVICE_MAX_COMPUTE_UNITS, sizeof(max_compute_units), &max_compute_units, &returned_size);
	
	printf("Vendor: %s\n", vendor_name);
	printf("Device Name: %s\n", device_name);
	printf("Profile: %s\n", device_profile);
	printf("Supported Extensions: %s\n\n", device_extensions);
	
	printf("Local Mem Type (Local=1, Global=2): %i\n",(int)local_mem_type);
	printf("Global Mem Size (MB): %i\n",(int)global_mem_size/(1024*1024));
	printf("Global Mem Cache Size (Bytes): %i\n",(int)global_mem_cache_size);
	printf("Max Mem Alloc Size (MB): %ld\n",(long int)max_mem_alloc_size/(1024*1024));
	
	printf("Clock Frequency (MHz): %i\n\n",clock_frequency);
	
	for(int i=0;i<6;i++){
		err|= clGetDeviceInfo(device_id, vector_types[i], sizeof(clock_frequency), &vector_width, &returned_size);
		printf("Vector type width for: %s = %i\n",vector_type_names[i],vector_width);
	}
	
	printf("\nMax Work Group Size: %lu\n",max_work_group_size);
	//printf("Max Work Item Dims: %lu\n",max_work_item_dims);
	//for(size_t i=0;i<max_work_item_dims;i++) 
	//	printf("Max Work Items in Dim %lu: %lu\n",(long unsigned)(i+1),(long unsigned)max_work_item_sizes[i]);
	
	printf("Max Compute Units: %i\n",max_compute_units);
	printf("\n");
	
	return CL_SUCCESS;
}

char * load_program_source(const char *filename)
{ 
	
	struct stat statbuf;
	FILE *fh; 
	char *source; 
	
	fh = fopen(filename, "r");
	if (fh == 0)
		return 0; 
	
	stat(filename, &statbuf);
	source = (char *) malloc(statbuf.st_size + 1);
	fread(source, statbuf.st_size, 1, fh);
	source[statbuf.st_size] = '\0'; 
	
	return source; 
} 

double machcore(uint64_t endTime, uint64_t startTime){
	
	uint64_t difference = endTime - startTime;
    static double conversion = 0.0;
	double value = 0.0;
	
    if( 0.0 == conversion )
    {
        mach_timebase_info_data_t info;
        kern_return_t err = mach_timebase_info( &info );
        
        if( 0 == err ){
			/* seconds */
            conversion = 1e-9 * (double) info.numer / (double) info.denom;
			/* nanoseconds */
			//conversion = (double) info.numer / (double) info.denom;
		}
    }
    
	value = conversion * (double) difference;
	
	return value;
}

void readfile(float *ax,float *ay,float *az,
			  float *gx,float *gy,float *gz,
			  float *charge,float *size,int natom,int ngrid){
	
	int i;	
	
	FILE * pFile = NULL;
	pFile = fopen("atom.txt","r");
	
	printf("Reading input file 1\n");
	for (i=0; i<natom; i++) {
		
		fscanf(pFile,"%g %g %g %g %g",
			   &ax[i],&ay[i],&az[i],&charge[i],&size[i]);
	}
	fclose(pFile);
	
	pFile = fopen("grid.txt","r");
	
	printf("Reading input file 2\n");
	for (i=0; i<ngrid; i++) {
		
		fscanf(pFile,"%g %g %g",
			   &gx[i],&gy[i],&gz[i]);
	}
	fclose(pFile);
	
	printf("Done reading inputs.");
}

void gendata(float *ax,float *ay,float *az,
			 float *gx,float *gy,float *gz,
			 float *charge,float *size,int natom,int ngrid){
	
	int i;	
	
	printf("Generating Data 1\n");
	for (i=0; i<natom; i++) {
		
		ax[i] = ((float) rand() / (float) RAND_MAX);
		ay[i] = ((float) rand() / (float) RAND_MAX);
		az[i] = ((float) rand() / (float) RAND_MAX);
		charge[i] = ((float) rand() / (float) RAND_MAX);
		size[i] = ((float) rand() / (float) RAND_MAX);
	}
	
	printf("Generating Data 2\n");
	for (i=0; i<ngrid; i++) {
		
		gx[i] = ((float) rand() / (float) RAND_MAX);
		gy[i] = ((float) rand() / (float) RAND_MAX);
		gz[i] = ((float) rand() / (float) RAND_MAX);
		
	}
	printf("Done generating inputs.\n\n");
}

void print_total(float * arr, int ngrid){
	double accum = 0.0;
	for (int i=0; i<ngrid; i++){
		accum += arr[i];
	}
	printf("Accumulated value: %1.7g\n",accum);
}

int exec_kernel(int ngrid,int natom,int ngadj,int naadj,
				float *ax,float *ay,float *az,
				float *gx,float *gy,float *gz,
				float *charge,float *size,float xkappa,
				float pre1,float *val,int itmax,const char * filename){

	cl_context			context;
	
    cl_command_queue	cmd_queue;
    cl_device_id		devices;

    cl_int				err;
	
	// Connect to a compute device
    err = clGetDeviceIDs(NULL,CL_DEVICE_TYPE_GPU, 1, &devices, NULL);
	
    size_t returned_size = 0;
    cl_char vendor_name[1024] = {0};
    cl_char device_name[1024] = {0};
    err = clGetDeviceInfo(devices, CL_DEVICE_VENDOR, sizeof(vendor_name), vendor_name, &returned_size);
    err|= clGetDeviceInfo(devices, CL_DEVICE_NAME, sizeof(device_name), device_name, &returned_size);
	
    printf("Connecting to %s %s...\n", vendor_name, device_name);
	//device_stats(devices);
	
    // Read the program
	printf("Loading program '%s'\n\n", filename);
	char *program_source = load_program_source(filename);
    
	//Create the context and command queue
	context = clCreateContext(0, 1, &devices, NULL, NULL, &err);
	cmd_queue = clCreateCommandQueue(context, devices, 0, NULL);
	
	//Allocate memory for programs and kernels
	cl_program program;
    cl_kernel kernel;
	
	//Create program from .cl file
	program = clCreateProgramWithSource(context,1, (const char**)&program_source, NULL, &err);
	
    // build the program (compile it)
    err = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
	char build[2048];
	clGetProgramBuildInfo(program, devices, CL_PROGRAM_BUILD_LOG, 2048, build, NULL);
	printf("Build Log:\n%s\n",build);
	
	// create the kernel 
    kernel = clCreateKernel(program, "mdh", &err);
	
	uint64_t mbeg, mend;
	double cl_alloc, cl_enqueue, cl_read;
	
	size_t atom_buffer_size = sizeof(float) * natom;
	size_t grid_buffer_size = sizeof(float) * ngrid;
	size_t gadj_buffer_size = sizeof(float) * ngadj;
	
	mbeg = mach_absolute_time();
	//Allocate memory and queue it to be written to the device
	cl_mem ax_mem = clCreateBuffer(context, CL_MEM_READ_ONLY, atom_buffer_size, NULL, NULL);
	err = clEnqueueWriteBuffer(cmd_queue, ax_mem, CL_TRUE, 0, atom_buffer_size, (void*)ax, 0, NULL, NULL);
	
	cl_mem ay_mem = clCreateBuffer(context, CL_MEM_READ_ONLY, atom_buffer_size, NULL, NULL);
	err = clEnqueueWriteBuffer(cmd_queue, ay_mem, CL_TRUE, 0, atom_buffer_size, (void*)ay, 0, NULL, NULL);
	
	cl_mem az_mem = clCreateBuffer(context, CL_MEM_READ_ONLY, atom_buffer_size, NULL, NULL);
	err = clEnqueueWriteBuffer(cmd_queue, az_mem, CL_TRUE, 0, atom_buffer_size, (void*)az, 0, NULL, NULL);
	
	cl_mem charge_mem = clCreateBuffer(context, CL_MEM_READ_ONLY, atom_buffer_size, NULL, NULL);
	err = clEnqueueWriteBuffer(cmd_queue, charge_mem, CL_TRUE, 0, atom_buffer_size, (void*)charge, 0, NULL, NULL);
	
	cl_mem size_mem	= clCreateBuffer(context, CL_MEM_READ_ONLY, atom_buffer_size, NULL, NULL);
	err = clEnqueueWriteBuffer(cmd_queue, size_mem, CL_TRUE, 0, atom_buffer_size, (void*)size, 0, NULL, NULL);
	
	cl_mem gx_mem = clCreateBuffer(context, CL_MEM_READ_ONLY, gadj_buffer_size, NULL, NULL);
	err = clEnqueueWriteBuffer(cmd_queue, gx_mem, CL_TRUE, 0, gadj_buffer_size, (void*)gx, 0, NULL, NULL);
	
	cl_mem gy_mem = clCreateBuffer(context, CL_MEM_READ_ONLY, gadj_buffer_size, NULL, NULL);
	err = clEnqueueWriteBuffer(cmd_queue, gy_mem, CL_TRUE, 0, gadj_buffer_size, (void*)gy, 0, NULL, NULL);
	
	cl_mem gz_mem = clCreateBuffer(context, CL_MEM_READ_ONLY, gadj_buffer_size, NULL, NULL);
	err = clEnqueueWriteBuffer(cmd_queue, gz_mem, CL_TRUE, 0, gadj_buffer_size, (void*)gz, 0, NULL, NULL);
	
	cl_mem val_mem = clCreateBuffer(context, CL_MEM_READ_WRITE, gadj_buffer_size, NULL, NULL);
	err = clEnqueueWriteBuffer(cmd_queue, val_mem, CL_TRUE, 0, gadj_buffer_size, (void*)val, 0, NULL, NULL);
	
	//Push the data out to device
	clFinish(cmd_queue);
	
	mend = mach_absolute_time();
	cl_alloc = machcore(mend, mbeg);
	
	// set work-item dimensions 
	size_t global_work_size, local_work_size, shared_size;
	global_work_size = ngadj;
	local_work_size = 64;
	shared_size = (5 * local_work_size) * sizeof(float);
	
	//Set kernel arguments
	err  = clSetKernelArg(kernel,  0, sizeof(cl_mem), &ax_mem);
	err |= clSetKernelArg(kernel,  1, sizeof(cl_mem), &ay_mem);
	err |= clSetKernelArg(kernel,  2, sizeof(cl_mem), &az_mem);
	err |= clSetKernelArg(kernel,  3, sizeof(cl_mem), &charge_mem);
	err |= clSetKernelArg(kernel,  4, sizeof(cl_mem), &size_mem);
	err |= clSetKernelArg(kernel,  5, sizeof(cl_mem), &gx_mem);
	err |= clSetKernelArg(kernel,  6, sizeof(cl_mem), &gy_mem);
	err |= clSetKernelArg(kernel,  7, sizeof(cl_mem), &gz_mem);
	err |= clSetKernelArg(kernel,  8, sizeof(float), &pre1);
	err |= clSetKernelArg(kernel,  9, sizeof(float), &xkappa);
	err |= clSetKernelArg(kernel, 10, sizeof(cl_mem), &val_mem);
	err |= clSetKernelArg(kernel, 11, sizeof(int), &natom);
	err |= clSetKernelArg(kernel, 12, shared_size, NULL);
	
	size_t thread_size;
	clGetKernelWorkGroupInfo(kernel,devices,CL_KERNEL_WORK_GROUP_SIZE,
							 sizeof(size_t),&thread_size,NULL);
	printf("Recommended Size: %lu\n",thread_size);
	
	mbeg = mach_absolute_time();
	//Queue up the kernels itmax times
	for(int i=0;i<itmax;i++)
		err = clEnqueueNDRangeKernel(cmd_queue, kernel, 1, NULL, &global_work_size, 
									 &local_work_size, 0, NULL, NULL);
	
	//Finish the calculation
	clFinish(cmd_queue);
	mend = mach_absolute_time();
	cl_enqueue = machcore(mend, mbeg);
	
	mbeg = mach_absolute_time();
	// read output image
	err = clEnqueueReadBuffer(cmd_queue, val_mem, CL_TRUE, 0, grid_buffer_size, val, 0, NULL, NULL);
	clFinish(cmd_queue);
	mend = mach_absolute_time();
	cl_read = machcore(mend, mbeg);
	
	printf("Allocation: %1.12g Enqueue: %1.12g Read: %1.12g\n",cl_alloc,cl_enqueue,cl_read);
	print_total(val, ngrid);

    // release kernel, program, and memory objects
	clReleaseKernel(kernel);
    clReleaseProgram(program);
    clReleaseCommandQueue(cmd_queue);
    clReleaseContext(context);
	
	clReleaseMemObject(ax_mem);
	clReleaseMemObject(ay_mem);
	clReleaseMemObject(az_mem);
	clReleaseMemObject(charge_mem);
	clReleaseMemObject(size_mem);
	
	clReleaseMemObject(gx_mem);
	clReleaseMemObject(gy_mem);
	clReleaseMemObject(gz_mem);
	
	clReleaseMemObject(val_mem);
	
	return CL_SUCCESS;
}

void scalar(int ngrid,int natom,float *ax,float *ay,float *az,float *gx,float *gy,float *gz,
			float *charge,float *size,float xkappa,float pre1,float *val,int parallel){
	
	int igrid, iatom;
	
	float dist;
	
	if(!parallel){
		for(igrid=0;igrid<ngrid;igrid++){
			val[igrid] = 0.f;
			for(iatom=0; iatom<natom; iatom++){
				dist = sqrtf((gx[igrid]-ax[iatom])*(gx[igrid]-ax[iatom]) + 
							 (gy[igrid]-ay[iatom])*(gy[igrid]-ay[iatom]) + 
							 (gz[igrid]-az[iatom])*(gz[igrid]-az[iatom]));
				
				val[igrid] += pre1*(charge[iatom]/dist)*expf(-xkappa*(dist-size[iatom]))
				/ (1+xkappa*size[iatom]);
			}
		}
	}else {
#pragma omp parallel for private(igrid,iatom,dist)
		for(igrid=0;igrid<ngrid;igrid++){
			val[igrid] = 0.f;
			for(iatom=0; iatom<natom; iatom++){
				dist = sqrtf((gx[igrid]-ax[iatom])*(gx[igrid]-ax[iatom]) + 
							 (gy[igrid]-ay[iatom])*(gy[igrid]-ay[iatom]) + 
							 (gz[igrid]-az[iatom])*(gz[igrid]-az[iatom]));
				
				val[igrid] += pre1*(charge[iatom]/dist)*expf(-xkappa*(dist-size[iatom]))
				/ (1+xkappa*size[iatom]);
			}
		}
	}

}

int main (int argc, const char * argv[]) {
    
	int itmax = 1;
	int natom, ngrid, ngadj, naadj;
	uint64_t beg, end;
	
	natom = 5877;
	ngrid = 134918;
	
	//Adjust the arrays for the grids to be a multiple of 512
	//This is done for performance reasons
	ngadj = ngrid + (512 - (ngrid & 511));
	
	float pre1 = 4.46184985145e19;
	float xkappa = 0.0735516324639;
	
	float *ax, *ay, *az, *charge, *size;
	float *gx, *gy, *gz;
	
	float *val1, *val2;
	
	//Allocate data storage
	ax = (float*)calloc(natom, sizeof(float));
	ay = (float*)calloc(natom, sizeof(float));
	az = (float*)calloc(natom, sizeof(float));
	charge = (float*)calloc(natom, sizeof(float));
	size = (float*)calloc(natom, sizeof(float));
	
	gx = (float*)calloc(ngadj, sizeof(float));
	gy = (float*)calloc(ngadj, sizeof(float));
	gz = (float*)calloc(ngadj, sizeof(float));
	
	val1 = (float*)calloc(ngadj, sizeof(float));
	val2 = (float*)calloc(ngadj, sizeof(float));
	
	//Generate some random data (the actual values are irrelevant for this example)
	gendata(ax, ay, az, gx, gy, gz, charge, size, natom, ngrid);
	
	//CPU calculation - Scalar
	beg = mach_absolute_time();
	scalar(ngadj, natom, ax, ay, az, gx, gy, gz, charge, size, xkappa, pre1, val1,0);
	end = mach_absolute_time();
	
	SEP;
	print_total(val1, ngrid);
	printf("CPU Loop - Scalar: %1.12g\n",machcore(end,beg));
	SEP;
	
	//CPU calculation - Parallel
	beg = mach_absolute_time();
	scalar(ngadj, natom, ax, ay, az, gx, gy, gz, charge, size, xkappa, pre1, val1,1);
	end = mach_absolute_time();
	
	SEP;
	print_total(val1, ngrid);
	printf("CPU Loop - Parallel: %1.12g\n",machcore(end,beg));
	SEP;
	
	//GPU - Unoptimized calculation
	SEP;
	beg = mach_absolute_time();
	exec_kernel(ngrid, natom, ngadj, naadj, 
				ax, ay, az, gx, gy, gz, 
				charge, size, xkappa, pre1, val2, itmax, "mdh_orig.cl");
	end = mach_absolute_time();
	printf("GPU Loop - Unoptimized: %1.12g\n",machcore(end,beg));
	SEP;
	
	//GPU - Optimized calculation
	SEP;
	beg = mach_absolute_time();
	exec_kernel(ngrid, natom, ngadj, naadj, 
				ax, ay, az, gx, gy, gz, 
				charge, size, xkappa, pre1, val2, itmax, "mdh_opt.cl");
	end = mach_absolute_time();
	printf("GPU Loop - Optimized: %1.12g\n",machcore(end,beg));
	SEP;
	
	//Clean up
	free(ax);
	free(ay);
	free(az);
	free(charge);
	free(size);
	
	free(gx);
	free(gy);
	free(gz);
	
	free(val1);
	free(val2);
	
    return 0;
}



















